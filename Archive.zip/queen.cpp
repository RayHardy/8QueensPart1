


// queen.cpp : Defines the entry point for the application.
//
#include "queen.hpp"

#include <iostream>
using namespace std;

Queen * Queen::lastQueen = nullptr;
static int qc = 0;

bool Queen::canAttack( const int r, const int c ) const
{
    if( _column == c ) return true;
    if( _row    == r ) return true;
    
    if( abs(_column-c) == abs(_row-r) ) return true;
    
    return false;
}

// constructor for each column
Queen::Queen( int col, Queen * ngh ) : _column( col ), _neighbor( ngh )
{
    _row = 1;
}


bool Queen::verifySolution( void )
{
    if( nullptr == next() )
    return true;
    
    for( Queen * tmp = next(); nullptr != tmp; tmp = tmp->next() )
    {
        if( tmp->canAttack( _row, _column ) )
        return false;
    }
    
    return next()->verifySolution();
}


bool Queen::move( queen_vec_t & v )
{
    if( 1 == _row ) v[_row]++;
    
    if( hasNext() && next()->move(v) ) return true;
    
    v[_row]--;
    
    _row++;
    
    while( _row <= BOARD_SIZE && v[_row]>0 ) _row++;
    
    if( _row <= BOARD_SIZE )
    {
        v[_row]++;
    }
    else
    {
        _row = 1;
        return false;
    }
    
    if( lastQueen->verifySolution() )
    {
        _print_solution();
        _print_qc();
    }
    
    return move(v);
}

void Queen::_print_solution()
{
    for( Queen * tmp = lastQueen; nullptr != tmp; tmp = tmp->next() )
    {
        cout << tmp->_row << " " << tmp->_column << endl;
    }
    cout << endl << endl;
    
    qc++;
}

void Queen::_print_qc(){
    cout << "possible known solutions: " << qc << endl << endl;
}


