
////
////  main.cpp
////  8Queens
////
////  Created by Raymon Hardy on 3/8/18.
////  Copyright © 2018 Raymon Hardy. All rights reserved.
////

#include <iostream>
#include <list>
using namespace std;
#include "queen.hpp"


int main( int argc, const char * argv[] )
{
    queen_vec_t v( BOARD_SIZE + 1 );
    
    for( int i = 1; i <= BOARD_SIZE; i++ )
    {
        Queen::lastQueen = new Queen( i, Queen::lastQueen );
    }
    
    Queen::lastQueen->move( v );
    
    
    Queen * tmp;
    while( nullptr != Queen::lastQueen )
    {
        tmp = Queen::lastQueen;
        Queen::lastQueen = Queen::lastQueen->next();
        delete tmp;
    }
    
    
}






