//
//  queen.hpp
//  8Queens
//
//  Created by Raymon Hardy on 3/8/18.
//  Copyright © 2018 Raymon Hardy. All rights reserved.
//

//#ifndef queen_hpp
#define queen_hpp

#include <stdio.h>

#pragma once

#include <vector>

using namespace std;

#define BOARD_SIZE 8

typedef vector<int> queen_vec_t;

class Queen {
    
    public:
    static Queen * lastQueen;
    
    // constructor
    Queen( int, Queen * );
    
    // Queen's functions
    bool verifySolution();
    bool move( queen_vec_t & v );
    
    int returnColumn() const { return _column; }
    int returnRow()    const { return _row;    }
    
    Queen * next()           { return _neighbor; }
    bool    hasNext()  const { return nullptr != _neighbor; }
    
    bool canAttack( const int r, const int c ) const;
    void advanceRow();
    
    
    private:
    // the Queens row can be moved
    // the Queens column cannot be moved
    // the Queen's neighbor
    
    int         _row;
    const int   _column;
    Queen     * _neighbor;
    
    void _print_solution();
    void _print_qc();
    
};

